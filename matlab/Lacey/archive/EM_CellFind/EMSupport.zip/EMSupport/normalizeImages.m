function normImgs = normalizeImages(origImgs)

normImgs=zeros(size(origImgs));

for imgInd=1:size(origImgs,3)
    thisImg=origImgs(:,:,imgInd);
    softMax=prctile(thisImg(:),99.9);
    if softMax>0
        normImgs(:,:,imgInd)=thisImg/softMax;
    end
end
