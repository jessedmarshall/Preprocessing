function [cEstNew, phiEstNew, toDelete, scaledPhi] = EM_genFilt_oneIteration(imgs, cEst, phiEst, varargin) %noiseSigma, useConstantBG, numSigmasThresh)

% cEst should be nCells x nPix - rows are flattened cell images
% same size as pXgivenZ .... because that's what the c's are!

% changing structure: now pXgivenZ and cEst will have flattened cell images
% as columns instead of rows

% this is for speed in summing the columns to calculate phiEst in every
% loop
% plus other possible speedups

cEst=single(cEst);
phiEst=single(phiEst);

options.numSigmasThres=0;
options.useConstantBG=1;
options.noiseSigma=0.005;
options.threshForElim=0.01;
options=getOptions(options,varargin);

nFrames=size(imgs,3);
imgSize=size(imgs(:,:,1));
nCells=size(cEst,1);
nPixX=imgSize(2);
nPixY=imgSize(1);
nPix=nPixX*nPixY;

thresh=options.numSigmasThres*options.noiseSigma;
fInc=options.noiseSigma/5;

phiEstNew=zeros(size(phiEst),'single');

pXgivenZ=cEst';

totCounts=zeros(1,nFrames,'single');
labelProbabilities=zeros(nPix,nCells,'single'); % same size as pZgivenX

pX=pXgivenZ*phiEst;
pX(pX==0)=10e-8;


thisTimeLabelProbs=zeros(nPix,nCells,'single'); % same size as pZgivenX

for t=1:nFrames
    
    % get photon counts
    counts=floor((imgs(:,:,t)-thresh)/fInc);
    counts(imgs(:,:,t)<thresh)=0;
    counts=counts(:);
    totCounts(t)=sum(counts);

    % update estimates from counts
    nonZeroInds=counts>0;
    if sum(nonZeroInds)>0
        
        countsOverPx=counts./pX(:,t);
        
        thisTimeLabelProbs(nonZeroInds,:)=bsxfun(@times,pXgivenZ(nonZeroInds,:),countsOverPx(nonZeroInds));
        thisTimeLabelProbs(nonZeroInds,:)=bsxfun(@times, thisTimeLabelProbs(nonZeroInds,:), phiEst(:,t)');


        phiEstNew(:,t)=sum(thisTimeLabelProbs(nonZeroInds,:),1); % don't divide by total number of counts yet, since need to divide mu est by phi est before

        %%%% reminder for size: labelProbabilities=zeros(nCells,nPix); % same size as pZgivenX
        labelProbabilities(nonZeroInds,:)=labelProbabilities(nonZeroInds,:)+thisTimeLabelProbs(nonZeroInds,:);
    end
end



%%%%% calc cEst by dividing labelProbabilities by the total weight for that
%%%%% cell
cEstNew=bsxfun(@rdivide,labelProbabilities',sum(phiEstNew,2));

scaledPhi=phiEstNew*fInc;
for t=1:nFrames
    if totCounts(t)>0
        phiEstNew(:,t)=phiEstNew(:,t)/totCounts(t);
    end
end

toDelete=zeros(1,nCells);
for cInd=1:nCells
    if max(phiEstNew(cInd,:))<options.threshForElim
        toDelete(cInd)=1;
    end
end

if sum(toDelete)==nCells
    toDelete(end)=0;
end

if options.useConstantBG
    cEstNew(end,:)=1/(size(cEstNew,2))*ones(1,size(cEstNew,2));
    toDelete(end)=0;
end

toDelete=logical(toDelete);
