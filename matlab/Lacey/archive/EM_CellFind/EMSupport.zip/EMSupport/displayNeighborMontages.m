function displayNeighborMontages(currentInd,cellParams,cellImages,cvxHulls,eventTimes,cellTraces,DFOF,varargin)

options.maxDist=10;
options=getOptions(options,varargin);
[mainCellEventMontage,~] = getEventMontage(eventTimes{currentInd}, cellTraces(currentInd,:), DFOF, cellParams(currentInd,:), cellImages(:,:,currentInd));

figure(470)
for cInd=1:length(eventTimes)
    if cInd~=currentInd && norm(cellParams(cInd,:)-cellParams(currentInd,:))<=options.maxDist
        if ~isempty(intersect(eventTimes{currentInd},eventTimes{cInd})) ||...
            ~isempty(intersect(eventTimes{currentInd}+1,eventTimes{cInd})) ||...
            ~isempty(intersect(eventTimes{currentInd}-1,eventTimes{cInd}))
        
            figure(470);
            subplot(131)
            imagesc(DFOF(:,:,eventTimes{currentInd}(1))); hold on;
            plot(cvxHulls{currentInd}(:,1),cvxHulls{currentInd}(:,2),'m')
            plot(cvxHulls{cInd}(:,1),cvxHulls{cInd}(:,2),'w')
            title('pink: original, white: neighbor')
            
            subplot(132)
            imagesc(mainCellEventMontage)
            title('Original cell montage')
            
            subplot(133)
            [eventMontage,~] = getEventMontage(eventTimes{cInd}, cellTraces(cInd,:), DFOF, cellParams(cInd,:), cellImages(:,:,cInd));
            imagesc(eventMontage)
            title('Neighbor cell montage')
            k=waitforbuttonpress;
            
            while k==0
                k=waitforbuttonpress;
            end
            
        end
    end
end