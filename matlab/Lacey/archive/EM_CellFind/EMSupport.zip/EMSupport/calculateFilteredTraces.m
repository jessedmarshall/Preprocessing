function cellTraces = calculateFilteredTraces(imgs, cellImages)

nFrames=size(imgs,3);
if numel(size(cellImages))==3
    nCells=size(cellImages,3);
    cellImages=reshape(cellImages, [numel(imgs(:,:,1)) nCells]);
else
    nCells=size(cellImages,2);
end
cellTraces=zeros(nCells,nFrames);
for cInd=1:nCells
    cellImages(:,cInd)=cellImages(:,cInd)/max(cellImages(:,cInd));
end

frInc=200;
for fr=1:frInc:nFrames
    endFrame=min(nFrames,fr+frInc-1);
    frameInds=fr:endFrame;
    thisImgs=imgs(:,:,frameInds)-1;
    %thisImgs(thisImgs<0)=0;
    thisImgs=reshape(thisImgs,[numel(imgs(:,:,1)) length(frameInds)])';
    theseTraces=thisImgs*cellImages;
    cellTraces(:,frameInds)=theseTraces';
end

