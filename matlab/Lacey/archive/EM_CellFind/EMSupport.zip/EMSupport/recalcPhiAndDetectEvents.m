function [scaledPhi, eventTimes] = recalcPhiAndDetectEvents(DFOF, cellImages, dsScaledPhi, EMoptions, varargin)

filtTraces = calculateFilteredTraces(DFOF, cellImages);

scaledPhi = calculateScaledPhi(cellImages, dsScaledPhi, DFOF, EMoptions);

EDoptions.tmp=0;
EDoptions=getOptions(EDoptions, varargin);
eventTimes = detectEventsOnPhi(filtTraces, scaledPhi, 'options', EDoptions);