function [options] = getOptionsWarnUnknown(options,inputArgs,varargin)
    % gets default options for a function, replaces with inputArgs inputs if they are present
    % biafra ahanonu
    % edited by Lacey Kitch
    % started: 2013.11.04
    %
    % inputs
    %   options - structure with options given
    %   inputArgs - as stated
    %
    % note
    %   use the 'options' name-value pair to input an options structure that will overwrite default options in a function, example below.
    %   options.Stargazer = 1;
    %   options.SHH = 0;
    %   getMutations(mutationList,'options',options);
    %
    %   This is in contrast to using name-value pairs, both will produce the same result.
    %   getMutations(mutationList,'Stargazer',1,'SHH',0);


    % changelog
    %   2014.02.12 [11:56:00] - added feature to allow input of an options structure that contains the options instead of having to input multiple name-value pairs.
    %   2014.07.10 [05:19:00] - added displayed warning if an option is input that was not present (this usually indicates typo)


    %Process options
    validOptions = fieldnames(options);

    % inputArgs = inputArgs{1};
    for i = 1:2:length(inputArgs)
        val = inputArgs{i};
        if ischar(val)
            %display([inputArgs{i} ': ' num2str(inputArgs{i+1})]);
            if strcmp('options',val)
                inputOptions = inputArgs{i+1};
                [options] = mirrorRightStruct(inputOptions,options);
            elseif ~isempty(strmatch(val,validOptions)) %#ok<MATCH2>
                % way more elegant
                options.(val) = inputArgs{i+1};
                try
                    [st,~]=dbstack;
                    callingFnc=st(2).name;
                catch
                    callingFnc='unknown function';
                end
                disp(['Warning: Unknown option input in ' callingFnc])
                % eval(['options.' val '=' num2str(inputArgs{i+1}) ';']);
            end
        else
            disp('Warning: enter parameter/struct name before options input')
            continue;
        end
    end
    %display(options);

function [pullStruct] = mirrorRightStruct(pushStruct,pullStruct)
    % overwrites fields in pullStruct with those in pushStruct, other pullStruct fields rename intact
    % more generally, copies fields in pushStruct into pullStruct, if there is an overlap in field names, pushStruct overwrites.
    pushNames = fieldnames(pushStruct);
    for name = 1:length(pushNames)
        iName = pushNames{name};
        if ~isfield(pullStruct, iName)
                try
                    [st,~]=dbstack;
                    callingFnc=st(3).name;
                catch
                    callingFnc='unknown function';
                end
            disp(['Warning: Option ' iName ' unknown in ' callingFnc])
        end
        pullStruct.(iName) = pushStruct.(iName);
    end