function [initImages, initProbs] = initImagesFromICs(icImgs, icTraces)

initImages = permute(icImgs, [3 1 2]);
initImages = reshape(initImages, [size(initImages,1), numel(icImgs(:,:,1))]);

initProbs=icTraces;
initProbs=bsxfun(@rdivide, initProbs, sum(initProbs,1));