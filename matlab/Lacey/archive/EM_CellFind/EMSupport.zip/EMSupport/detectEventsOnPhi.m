function [eventTimes, cellTraceSigmas, options] = detectEventsOnPhi(cellTraces, scaledPhi, varargin)

% Written by Lacey Kitch and Maggie Carr Larkin in 2013

% cellTraces is nCells x nFrames

%%%%% Input options:
% the number of std devs above baseline we require
options.numSigmasThresh=5;

% framerate of input movie
options.framerate=4;

% length of time (in seconds) that burst is required to remain above
% threshold (on average)
options.burstDuration=1;    % duration in seconds

% minimum time (in seconds) between bursts
options.refractoryPeriod=1.5;

% option to require peaks to be a minimum distance above their neighbors
options.diffThreshold=0;


options=getOptionsWarnUnknown(options,varargin);

warning('off', 'signal:findpeaks:largeMinPeakHeight')
    
nCells = size(cellTraces,1);
cellTraceSigmas = zeros(nCells,1);
eventTimes=cell(nCells,1);
for cInd=1:nCells
    thisPhi = scaledPhi(cInd,:);
    thisTrace = cellTraces(cInd,:);

    %Identify the threshold to use for probability
    %Ignore really small values
    threshTrace = thisTrace(thisPhi<0.1);
    if ~isempty(threshTrace)
%         val = reshape(threshTrace(1:end-mod(length(threshTrace),window)),floor(length(threshTrace)./window),window);
%         if isempty(val)
%             val=threshTrace;
%         end
%         cellTraceSigmas(cInd)=min(std(val,[],2));
        cellTraceSigmas(cInd)=std(threshTrace);
        probabilityThreshold = options.numSigmasThresh*cellTraceSigmas(cInd); clear threshTrace val
        

        %Find peaks that are greater than the probability threshold and far enough apart
        [~, spiketimes] = findpeaks(thisPhi,'minpeakheight',probabilityThreshold,...
            'minpeakdistance',round(options.refractoryPeriod*options.framerate),...
            'threshold', options.diffThreshold);

        %Require that the trace remains above threshold for long enough
        eventTimes{cInd} = intersect(spiketimes, find(filtfilt(ones(1,...
            round(options.burstDuration*options.framerate))/...
            round(options.burstDuration*options.framerate),1,...
            thisPhi)>(probabilityThreshold)));
    end
end