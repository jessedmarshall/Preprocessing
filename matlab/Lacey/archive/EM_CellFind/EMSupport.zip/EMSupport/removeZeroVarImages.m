function [cellImages, goodInds] = removeZeroVarImages(cellImages)

nImages=size(cellImages,3);
imgsToDelete=zeros(nImages,1);
for k=1:nImages
    thisImage=cellImages(:,:,k);
    thisImage(thisImage==0)=max(thisImage(:));
    if max(thisImage(:))==min(thisImage(:))
        imgsToDelete(k)=1;
    end
end
imgsToDelete=logical(imgsToDelete);
cellImages(:,:,imgsToDelete)=[];
goodInds=1:nImages;
goodInds(imgsToDelete)=[];