function cellFitParams = gridInitialize(imgs,centroidSpacing,varargin)

if nargin<2
    centroidSpacing=6;
end
defaultWidth=15;

for i=1:2:length(varargin)
    val=lower(varargin{i});
    switch val
        case 'width'
            defaultWidth=varargin{i+1};
    end
end

% xCoords=-(centroidSpacing/2):centroidSpacing:size(imgs,2)+(centroidSpacing/2);
% yCoords=-(centroidSpacing/2):centroidSpacing:size(imgs,1)+(centroidSpacing/2);
xCoords=0:centroidSpacing:size(imgs,2);
yCoords=0:centroidSpacing:size(imgs,1);

[xCentroids, yCentroids]=meshgrid(xCoords,yCoords);

evenRows=2:2:size(xCentroids,1);

xCentroids(evenRows,:)=xCentroids(evenRows,:)+centroidSpacing/2;

nGaussians=numel(xCentroids);
cellFitParams=[xCentroids(:), yCentroids(:), defaultWidth*ones(nGaussians,2), zeros(nGaussians,1)]; 

