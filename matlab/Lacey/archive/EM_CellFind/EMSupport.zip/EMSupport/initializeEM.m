function cellFitParams = initializeEM(imgs, timeWiggleRoom,...
    threshParam, minCellArea, maxCellArea, displayRegions,...
    displayGaussianFits, displayFramesToFit, displayMovie,...
    framerate, areaOverlapThresh, noiseSigma, varargin)

% Written by Lacey Kitch in 2013

% image segmentation based on timing of maximum pixel value
% includes gaussian fits for each cell (in max frame)
% also includes an optional initialization with ICA results

% imgs: raw data
% timeWiggleRoom: number of frames that the max times of nearby pixels are
%   allowed to be apart and still classified as the same region
% threshParam: either a raw value (like 1.008) or a percentile (like 30)
% minCellArea: minimum area of max time clustered region, in pixels
% maxCellArea: maxmimum area
% displayRegions: toggle, to display the max time regions
% displayGaussianFits: toggle, to display the gaussian fits to cell maxes
% displayFramesToFit: toggle, to display the max frames for fitting
% displayMovie: toggle, to display the movie after a cell's image has been
%   subtracted

haveBG=0;
suppressOutput=0;
if ~isempty(varargin)
    options=varargin{1};
    if isfield(options, 'localICimgs')
        if ~isempty(options.icImgs)
            initWithICs=1;
            icImgs=options.localICimgs;
        else
            initWithICs=0;
        end
        if isfield(options, 'localICtraces')
            icTraces=options.localICtraces;
        else
            warning('Must include both IC images and IC traces if you want to initialize with ICA results');
            initWithICs=0;
        end
        if isfield(options, 'initWithICsOnly')
            initWithICsOnly=options.initWithICsOnly;
            initWithICs=1;
        else
            initWithICsOnly=0;
        end
    else
        initWithICs=0;
    end
    if isfield(options, 'bg')
        haveBG=1;
        bg=options.bg;
    end
    if isfield(options, 'vlm')
        if options.vlm && ~haveBG
            disp('Waring: calculating traces without taking background into account')
        end
    end
end

% general values needed for all initialization
imgSize=size(imgs(:,:,1));
nFrames=size(imgs,3);
fitWidth=6;    % width for finding subregion of frame to fit gaussian


% get initialization from IC images by looking at the frames of the movie
% where the IC trace is maximal (rather than fitting to IC image)

yDim=find(size(icImgs)==imgSize(1),1,'first');
xDim=find(size(icImgs)==imgSize(2),2);
xDim(xDim==yDim)=[];

if isempty(yDim) || isempty(xDim)
    error('icImgs is the wrong size')
else
    icDim=1:3;
    icDim([xDim, yDim])=[];
    icImgs=permute(icImgs, [yDim, xDim, icDim]);
    nICs=size(icImgs,3);

    if size(icTraces,1)~=nICs
        icTraces=icTraces';
    end

    if size(icTraces,1)~=nICs || size(icTraces,2)~=nFrames
        error('icTraces is the wrong size')
    end
end

cellFitParams=zeros(nICs,5);
for icInd=1:nICs
    frameToFit=getFrameToFit(icTraces(icInd,:),imgs,noiseSigma,20);
    if haveBG
        frameToFit=double(frameToFit-bg-1);
    else
        frameToFit=double(frameToFit-1);
    end
    thisRegionLabeled=icImgs(:,:,icInd);
    [maxVal,maxPixelLoc]=max(thisRegionLabeled(:));
    thisRegionLabeled(thisRegionLabeled<0.3*maxVal)=0;
    thisRegionLabeled(thisRegionLabeled>0)=1;
    thisRegionLabeled(thisRegionLabeled<0)=0;
    thisRegionLabeled=logical(thisRegionLabeled);
    thisRegionLabeled=bwlabel(thisRegionLabeled,4);
    thisRegionLabeled(thisRegionLabeled~=thisRegionLabeled(maxPixelLoc))=0;
    [params,~,~]=fit2DgaussToImgSubregion(frameToFit, logical(thisRegionLabeled),...
        maxPixelLoc, fitWidth, displayFramesToFit);

    if displayFramesToFit
        cellImg=calcCellImgs(params, size(frameToFit));
        figure(97);
        %subplot(131); imagesc(frameToFit); 
        subplot(132); imagesc(icImgs(:,:,icInd));
        subplot(133); imagesc(cellImg);
        pause(1)
    end
    if ~isempty(params)
        cellFitParams(icInd,:)=params(1:5);
    end
end
cellFitParams(sum(cellFitParams,2)==0,:)=[];


calcTraces=0;
[~,cellFitParams,~]=resolveBorderConflicts(cellFitParams,areaOverlapThresh,imgs,calcTraces);


% to github from file segmentImageByMaxTime_LSsub on 12/11/13 at 5:59pm
