function [sqSizeX, sqSizeY, nSqHorz, nSqVert, sqIncX, sqIncY] = findOptimalSquareSize(maxSqSize,desOverlap,imgs)

nSquares=1:8;
optSqSizesX=zeros(size(nSquares));
optSqSizesY=zeros(size(nSquares));
imgSize=size(imgs(:,:,1));

for nSqInd=1:length(nSquares)
    nSq=nSquares(nSqInd);
    optSqSizesX(nSqInd)=(imgSize(2)+(nSq-1)*desOverlap)/nSq;
    optSqSizesY(nSqInd)=(imgSize(1)+(nSq-1)*desOverlap)/nSq;
end

sqSizeX=round(optSqSizesX(find(optSqSizesX<=(maxSqSize+1), 1, 'first')));
sqSizeY=round(optSqSizesY(find(optSqSizesY<=(maxSqSize+1), 1, 'first')));
nSqHorz=nSquares(find(optSqSizesX<=(maxSqSize+1), 1, 'first'));
nSqVert=nSquares(find(optSqSizesY<=(maxSqSize+1), 1, 'first'));

sqIncX=sqSizeX-desOverlap;
sqIncY=sqSizeY-desOverlap;