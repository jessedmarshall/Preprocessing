readme:


ex1_spikecounts:
	61 neurons, 400ms spike trains, 1ms resolution, 7 conditions, 30 trials/condition

ex1_neuralstates:
	6 latent variables, 7 conditions, 30 neural states/condition


ex2_rawspiketrains:
	61 neurons, 1015-1582ms spike trains, 1ms resolution, 2 conditions, 56 trials/condition

ex2_singletrialtrajs:
	15 latent variables, 50 to 80 timepoints/trial, 2 conditions, 15 trials/condition


ex3_psths:
	61 neurons, 1ms resolution, 2 conditions, so 122 PSTHs in total 

ex3_trialavgtrajs:
	6 latent variables, 27 conditions
